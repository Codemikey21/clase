/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Migue
 */
public class Helado {
    private String sabor;
    private String tipo;
    private double precio;
    private int cantidad;
    private boolean topping;
   
    public Helado (String sabor,String tipo, double precio, int cantidad, boolean topping ) {
        this.sabor = sabor;
        this.tipo = tipo;
        this.precio = precio;
        this.cantidad=cantidad;
        this.topping=topping;
    }
   public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidadStock() {
        return cantidad;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidad = cantidadStock;
    }

    public boolean isTieneTopping() {
        return topping;
    }

    public void setTieneTopping(boolean tieneTopping) {
        this.topping = tieneTopping;
    }  
    public void derretir() {
        System.out.println("El helado de " + sabor + " se est� derritiendo...");
    }
   
       public void servir() {
        System.out.println("Sirviendo helado de " + sabor + " en " + tipo);
    }

    public void agregarTopping(String topping) {
        this.topping = true;
        System.out.println("Se agreg� " + topping + " al helado de " + sabor);
    }

    public boolean verificarDisponibilidad(int cantidadDeseada) {
        return cantidad >= cantidadDeseada;
    }

    public void actualizarPrecio(double porcentajeAumento) {
        this.precio += this.precio * (porcentajeAumento / 100);
        System.out.println("Nuevo precio del helado de " + sabor + ": $" + precio);
   
    }
}