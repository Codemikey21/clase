/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Migue
 */
public class Computador {
    private String marca;
    private String procesador;
    private int ramGB;
    private int almacenamientoGB;
    private boolean tieneTarjetaGrafica;
    
    public Computador(String marca, String procesador, int ramGB, int almacenamientoGB, boolean tieneTarjetaGrafica) {
        this.marca = marca;
        this.procesador = procesador;
        this.ramGB = ramGB;
        this.almacenamientoGB = almacenamientoGB;
        this.tieneTarjetaGrafica = tieneTarjetaGrafica;
    }
    
    public String getMarca(){
        return marca;
    }
    
    public String getProcesador(){
        return procesador;
    }
    
    public int getRamGB() {
        return ramGB;
    }
    
    public int getAlmacenamientoGB() {
        return almacenamientoGB;
    }
    
    public boolean isTieneTarjetaGrafica() {
        return tieneTarjetaGrafica;
    }
    
    // Setters
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }
    
    public void setRamGB(int ramGB) {
        this.ramGB = ramGB;
    }
    
    public void setAlmacenamientoGB(int almacenamientoGB) {
        this.almacenamientoGB = almacenamientoGB;
    }
    
    public void setTieneTarjetaGrafica(boolean tieneTarjetaGrafica) {
        this.tieneTarjetaGrafica = tieneTarjetaGrafica;
    }
    
    public void encender() {
        System.out.println("El computador " + marca + " est� encendiendo...");
    }
    
    public void apagar() {
        System.out.println("El computador " + marca + " se est� apagando...");
    }
    
    public void ejecutarPrograma(String programa) {
        System.out.println("Ejecutando " + programa + " en el computador " + marca);
    }
    
    public void actualizarRAM(int nuevaRAM) {
        this.ramGB = nuevaRAM;
        System.out.println("RAM actualizada a " + nuevaRAM + "GB");
    }
    
    public String obtenerEspecificaciones() {
        return "Marca: " + marca + ", Procesador: " + procesador + ", RAM: " + ramGB + "GB, Almacenamiento: " + almacenamientoGB + "GB";
    }
}