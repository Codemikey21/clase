/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Migue
 */
public class TipoBank {
    public static void main(String[] args) {
        // ========== OPERACIONES CON BANCOS ==========
        System.out.println("========== SISTEMA BANCARIO ==========");
        bank banco1 = new bank("Banco de Cr�dito", "Bancolombia 3055, Colombia", "20100035370", 500);
        bank banco2 = new bank("Interbank", "Av. Carlos Villar�n 140, Santa Anita", "20100021248", 350);
        bank banco3 = new bank("Scotiabank", "Av. Dionisio Derteano 102, San Isidro", "20100039155", 400);
        
        System.out.println("\nBancos disponibles: ");
        System.out.println("1. " + banco1.getNombre());
        System.out.println("2. " + banco2.getNombre());
        System.out.println("3. " + banco3.getNombre());
        
        System.out.println("\nOperaciones bancarias: ");
        banco1.abrirCuenta("Ahorros", "Juan Buitrago");
        banco2.depositar("123-456-789", 1500.50);
        banco3.retirar("987-654-321", 500.00);
        banco1.transferir("123-456-789", "987-654-321", 300.75);
        
        banco2.setNombre("Bancolombia");
        System.out.println("\nNuevo nombre del banco 2: " + banco2.getNombre());
        
        System.out.println("\nInformaci�n completa banco 1:");
        System.out.println("Nombre: " + banco1.getNombre());
        System.out.println("Direcci�n: " + banco1.getDireccion());
        System.out.println("RUC: " + banco1.getRuc());
        System.out.println("Sucursales: " + banco1.getNumeroSucursales());

        // ========== OPERACIONES CON COMPUTADORES ==========
        System.out.println("\n\n========== SISTEMA DE COMPUTADORES ==========");
        Computador pc1 = new Computador("HP", "Intel i7", 16, 512, true);
        Computador pc2 = new Computador("Dell", "AMD Ryzen 5", 8, 256, false);
        
        System.out.println("\nComputadores disponibles:");
        System.out.println("1. " + pc1.getMarca() + " - " + pc1.getProcesador());
        System.out.println("2. " + pc2.getMarca() + " - " + pc2.getProcesador());
        
        System.out.println("\nOperaciones con computadores:");
        pc1.encender();
        pc2.ejecutarPrograma("Photoshop");
        pc1.actualizarRAM(32);
        System.out.println("Especificaciones PC1: " + pc1.obtenerEspecificaciones());
        pc1.apagar();

        // ========== OPERACIONES CON HELADOS ==========
        System.out.println("\n\n========== HELADER�A ==========");
        Helado helado1 = new Helado("Chocolate", "Cono", 3.50, 10, false);
        Helado helado2 = new Helado("Fresa", "Copa", 4.20, 5, true);
        
        System.out.println("\nSabores disponibles:");
        System.out.println("1. " + helado1.getSabor() + " - $" + helado1.getPrecio());
        System.out.println("2. " + helado2.getSabor() + " - $" + helado2.getPrecio());
        
        System.out.println("\nOperaciones con helados:");
        helado1.servir();
        helado2.agregarTopping("chispas de colores");
        System.out.println("�Hay suficiente helado de fresa? " + helado2.verificarDisponibilidad(3));
        helado1.derretir();
        helado1.actualizarPrecio(10);
        System.out.println("Nuevo stock de " + helado1.getSabor() + ": " + helado1.getCantidadStock());
        
        // ========== RESUMEN FINAL ==========
        System.out.println("\n\n========== RESUMEN GENERAL ==========");
        System.out.println("Banco principal: " + banco1.getNombre());
        System.out.println("Computador m�s potente: " + pc1.getMarca() + " con " + pc1.getRamGB() + "GB RAM");
        System.out.println("Helado m�s caro: " + helado2.getSabor() + " a $" + helado2.getPrecio());
    }
}