/**
 *
 * @author Migue
 */
public class bank {
   
    private String nombre;
    private String direccion;
    private String ruc;
    private int numeroSucursales;
    
    
    public bank(String nombre, String direccion, String ruc, int numeroSucursales) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.ruc = ruc;
        this.numeroSucursales = numeroSucursales;
    }
    
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getDireccion() {
        return direccion;
    }
    
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    
    public String getRuc() {
        return ruc;
    }

    public int getNumeroSucursales() {
        return numeroSucursales;
    }

    public void setNumeroSucursales(int numeroSucursales) {
        this.numeroSucursales = numeroSucursales;
    }
    
    public boolean abrirCuenta(String tipoCuenta, String cliente) {
        System.out.println("Abriendo cuenta " + tipoCuenta + " para " + cliente);
        return true;
    }
    
    public boolean depositar(String numeroCuenta, double monto) {
        System.out.println("Depositando " + monto + " a la cuenta " + numeroCuenta);
        return true;
    }
    
    public boolean retirar(String numeroCuenta, double monto) {
        System.out.println("Retirando " + monto + " de la cuenta " + numeroCuenta);
        return true;
    }
    
    public boolean transferir(String cuentaOrigen, String cuentaDestino, double monto) {
        System.out.println("Transfiriendo " + monto + " de " + cuentaOrigen + " a " + cuentaDestino);
        return true;
    }
    
    public void consultarSaldo(String numeroCuenta) {
        System.out.println("Consultando saldo de la cuenta " + numeroCuenta);
    }
}